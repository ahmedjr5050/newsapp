package com.example.ml_classifier

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
