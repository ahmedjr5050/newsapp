# Mask Detection
Preview of the Project

![](assets/1.png)
![](assets/2.png)

