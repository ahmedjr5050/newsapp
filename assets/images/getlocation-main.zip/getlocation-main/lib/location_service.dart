class UserLocation {
  static double lat = 0;
  static double long = 0;
}